# Piyasa Pusulası — 2027

Tek sayfalı, mobil uyumlu finans/piyasa terminali. Ana sayfa, grafikler, analiz yazıları, notlar, terim sözlüğü, anket, podcast alanı, bilgi testi ve yönetici arayüzü aynı ekranda birleştirilmiştir.

## GitHub + Netlify
1. Bu klasörün içeriğini GitHub'da yeni bir repository'ye yükleyin.
2. Netlify'da **Add new site → Import an existing project** seçin ve repository'yi bağlayın.
3. Build command boş, Publish directory `.` olsun.
4. Deploy edin.

## Entegrasyon ve güvenlik durumu
- Grafikler TradingView gömülü widgetlarıyla gelir. Sembol/borsa bazında veri gecikmesi ve kullanım koşulları değişebilir; uygulama emir iletmez.
- Paket tek başına gerçek zamanlı piyasa veri API'si, yapay zekâ analiz servisi veya ortak yönetici veritabanı içermez. Bunlar için sunucu tarafı API, sağlayıcı anahtarları ve uygun veri lisansı gerekir.
- Yönetici API adresi yapılandırılmadığından yerel mod yalnızca o tarayıcıda saklama yapar. Yerel PIN güvenli kimlik doğrulaması değildir; değişiklikler ziyaretçilere aktarılmaz.
- Yapay zekâ taslağı ve ortak içerik yönetimi için Cloudflare Worker/Netlify Functions veya Supabase Edge Functions gibi sunucu katmanı kurulmalı; API anahtarları yalnızca sunucu ortam değişkenlerinde tutulmalıdır.
- Kendi hesapladığımız RSI/MACD/EMA/ATR ve destek/direnç için lisanslı OHLC API bağlantısı gerekir.
- E-posta bülteni için form servisi, KVKK aydınlatma metni ve açık rıza akışı yapılandırılmalıdır.

## Yayın öncesi kontrol
Mobil ve masaüstünde menü/grafik kontrollerini deneyin. Gerçek veri ve AI servisi bağlanana kadar otomatik fiyat/AI yorumu varmış gibi tanıtım yapmayın. API anahtarlarını GitHub'a yüklemeyin.
